avahi-publish-service IoTParkingServer-Group4 _coap._udp 5683 “/mylight”
java -jar leshanparkingserver-group4.jar -lh 192.168.178.44 -wh 192.168.178.44
