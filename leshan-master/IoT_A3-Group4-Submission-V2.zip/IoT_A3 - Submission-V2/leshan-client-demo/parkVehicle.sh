mkdir spot_occupied
cd spot_occupied
mkdir $1


