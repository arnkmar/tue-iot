rm -r spot_occupied

